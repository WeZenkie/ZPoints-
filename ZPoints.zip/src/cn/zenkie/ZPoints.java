package cn.zenkie;

import java.io.File;
import java.io.IOException;

import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.plugin.java.JavaPlugin;

class Operation {
	
	public static String replace(String str) {
		String key = "\t";
		return str.replace(key, "       ");
	}
	public static String[] replace(String[] str) {
		String key = "\t";
		String[] str1 = str;
		for(int i = 0 ; i < str1.length ; i++) {
			str1[i] = str1[i].replace(key,"       ");
		}
		return str1;
	}
	
}


public class ZPoints extends JavaPlugin implements Listener {
	File playerDataFile;
	FileConfiguration playerData;
	@Override
	public void onEnable() {
		this.getLogger().info("插件启动");
		this.saveResource("Data/playerData.yml", false);
		playerDataFile = new File(getDataFolder(),"Data/playerData.yml");
		playerData = YamlConfiguration.loadConfiguration(playerDataFile);
		Bukkit.getPluginCommand("points").setExecutor(new Commands());
	}
	
	@EventHandler
	public void onPlayerJoin(PlayerJoinEvent e) {
		
	}
	
	@Override
	public void onDisable() {
		this.getLogger().info("插件关闭");
	}
	
	class Commands implements CommandExecutor {
	//命令类
		String[] help = {
				//help信息
				"/points help   获取帮助",
				"/points check  查询积分",
				"/points add    增加积分",
				"/points cut    扣除积分"
		},grammer = {
				//语法表
				"/points  help",
				"/points  check  [玩家]",
				"/points  add  [玩家]  <数量>",
				"/points  cut  [玩家]  <数量>"
		},aliases = {
				//别名表
				"帮助",
				"查询，检查，查看，查",
				"增加，加",
				"减少，减，扣除，扣"
		};
		String[][] keys = {
				//用来判断别名
				{"help","帮助"},
				{"check","查询","检查","查看","查"},
				{"add","增加","加"},
				{"减少","减","扣除","扣"}
		};

		public String type(String arg) {
			for(int i = 0 ; i < keys[0].length ; i++) {
				if(keys[0][i].equals(arg)) {
					return "help";
				}
			}
			for(int i = 0 ; i < keys[1].length ; i++) {
				if(keys[1][i].equals(arg)) {
					return "check";
				}
			}
			for(int i = 0 ; i < keys[2].length ; i++) {
				if(keys[2][i].equals(arg)) {
					return "add";
				}
			}
			for(int i = 0 ; i < keys[3].length ; i++) {
				if(keys[3][i].equals(arg)) {
					return "cut";
				}
			}
			return arg;
		}
		
		@SuppressWarnings("deprecation")
		@Override
		public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
			OfflinePlayer p;
			String key;
			long value;
			if(args.length == 0) {
				//无餐执行
				sender.sendMessage("输入: /points help 获取帮助");
				return true;
			} else if(args.length == 1) {
				//单参执行
				switch(type(args[0])) {
				case "help":
					//获取帮助信息
					sender.sendMessage(help);
					sender.sendMessage("注意：[]表示可选，<>表示必填");
					return true;
				case "check":
					//查询积分
					if(sender instanceof ConsoleCommandSender) {
						//控制台不能查询自己
						sender.sendMessage("在控制台使用这条命令需要[玩家]参数哦");
						return true;
					}
					if(sender instanceof Player) {
						//查询玩家自己的积分并提示
						p = (Player)sender;
						key = "Data." + p.getUniqueId() + ".score";
						value = playerData.getLong(key,0);
						sender.sendMessage("您还剩余： " + value + " 积分");
						return true;
  					}
				case "add":
					//获取add帮助信息
					sender.sendMessage(grammer[2]);
					return true;
				case "cut":
					//获取add帮助信息
					sender.sendMessage(grammer[3]);
					return true;
				default:
					sender.sendMessage("命令格式不正确，请输入: /points help 获取帮助");
					return true;
				}
			} else if(args.length == 2) {
				//两个参数
				switch(type(args[0])) {
				case "check":
					//查询积分
					p = Bukkit.getOfflinePlayer(args[1]);
					if(p.hasPlayedBefore()) {
						key = "Data." + p.getUniqueId() + ".score";
						value = playerData.getLong(key,0);
						sender.sendMessage("玩家" + p.getName() + "剩余" + value + "积分");
						return true;
					} else {
						sender.sendMessage("玩家： " + args[0] + " 不存在");
						return true;
					}
				case "add":
					//增加积分
					if(args[1].equals("help")) {
						//获取add的帮助
						sender.sendMessage(grammer[2]);
						return true;
					}
					if(args[1].equals("aliases")) {
						//获取add的别名
						sender.sendMessage(aliases[2]);
						return true;
					}
					if(sender instanceof ConsoleCommandSender) {
						//控制台不能自我奖励
						sender.sendMessage("在控制台使用这条命令需要[玩家]和<数量>参数哦");
						return true;
					}
					if(sender instanceof Player) {
						//玩家输入命令
						p = (Player)sender;
						if(p.isOp()) {
							//玩家是OP
							key = "Data." + p.getUniqueId() + ".score";
							try {
								value = playerData.getInt(key,0) + Long.parseLong(args[1]);
								playerData.set(key, value);
								playerData.save(playerDataFile);
								sender.sendMessage("您为自己添加了" + Long.parseLong(args[1]) + "积分");
								return true;
							} catch(NumberFormatException e) {
								//<数量>不是整数
								sender.sendMessage(args[1] + "好像不是一个整数诶？");
								return true;
							} catch (IOException e) {
								//数据文件丢失
								sender.sendMessage("数据文件丢失,请联系管理员重载插件");
								return true;
							}
						} else {
							//玩家不是OP
							sender.sendMessage("你还不是OP哦，不能使用这条命令");
							return true;
						}
					}
					case "cut":
						//扣除积分
						if(args[1].equals("help")) {
							//获取cut的帮助
							sender.sendMessage(grammer[3]);
							return true;
						}
						if(args[1].equals("aliases")) {
							//获取cut的别名
							sender.sendMessage(aliases[3]);
							return true;
						}
						if(sender instanceof ConsoleCommandSender) {
							//控制台不能自我扣除
							sender.sendMessage("在控制台使用这条命令需要[玩家]和<数量>参数哦");
							return true;
						}
						if(sender instanceof Player) {
							//玩家输入命令
							p = (Player)sender;
							if(p.isOp()) {
								//sender是OP
								key = "Data." + p.getUniqueId() + ".score";
								try {
									value = playerData.getInt(key,0) - Long.parseLong(args[1]);
									playerData.set(key, value);
									playerData.save(playerDataFile);
									sender.sendMessage("您为自己扣除了" + Long.parseLong(args[1]) + "积分");
									return true;
								} catch(NumberFormatException e) {
									sender.sendMessage(args[1] + "好像不是一个整数诶？");
									return true;
								} catch (IOException e) {
									sender.sendMessage("数据文件丢失,请联系管理员重载插件");
									return true;
								}
							} else {
								//sender不是OP
								sender.sendMessage("喵~管理员才能使用这条命令呢");
								return true;
							}
						}
				default:
					sender.sendMessage("命令格式不正确，请输入: /points help 获取帮助");
					return true;
				}
			} else if(args.length == 3) {
				//三参执行
				switch(type(args[0])) {
				case "add":
					//奖励积分
					if(sender instanceof ConsoleCommandSender) {
						//控制台直接奖励
						if(Bukkit.getOfflinePlayer(args[1]).hasPlayedBefore()) {
							//玩家存在
							p = Bukkit.getOfflinePlayer(args[1]);
							key = "Data." + p.getUniqueId() + ".score";
							try {
								value = playerData.getLong(key) + Long.parseLong(args[2]);
								playerData.set(key, value);
								playerData.save(playerDataFile);
								sender.sendMessage("你成功奖励了 " + p.getName() + " :" + args[2] + "积分");
								((Player) p).sendMessage("管理员奖励了你 " + args[2] + " 积分");
								return true;
							} catch(NumberFormatException e) {
								//<数量>不是整数
								sender.sendMessage(args[1] + "好像不是一个整数诶？");
								return true;
							} catch(IOException e) {
								//数据文件丢失
								sender.sendMessage("数据文件丢失,请联系管理员重载插件");
								return true;
							}
						} else {
							//玩家不存在
							sender.sendMessage("玩家： " + args[1] + " 不存在");
							return true;
						}
					}
					if(sender instanceof Player) {
						//玩家输入命令
						if(sender.isOp()) {
							//sender是OP
							p = Bukkit.getOfflinePlayer(args[1]);
							key = "Data." + p.getUniqueId() + ".score";
							try {
								value = playerData.getInt(key) + Long.parseLong(args[2]);
								playerData.set(key, value);
								playerData.save(playerDataFile);
								sender.sendMessage("你成功奖励了 " + p.getName() + " :" + args[2] + "积分");
								((Player) p).sendMessage(((Player)sender).getName() + "奖励了你 " + args[2] + " 积分");
								return true;
							} catch(NumberFormatException e) {
								//<数量>不是整数
								sender.sendMessage(args[1] + "好像不是一个整数诶？");
								return true;
							} catch(IOException e) {
								//数据文件丢失
								sender.sendMessage("数据文件丢失,请联系管理员重载插件");
								return true;
							}
						} else {
							//sender不是OP
							sender.sendMessage("喵~管理员才能使用这条命令呢");
							return true;
						}
					}
				case "cut":
					//奖励积分
					if(sender instanceof ConsoleCommandSender) {
						//控制台直接奖励
						if(Bukkit.getOfflinePlayer(args[1]).hasPlayedBefore()) {
							//玩家存在
							p = Bukkit.getOfflinePlayer(args[1]);
							key = "Data." + p.getUniqueId() + ".score";
							try {
								value = playerData.getLong(key) - Long.parseLong(args[2]);
								playerData.set(key, value);
								playerData.save(playerDataFile);
								sender.sendMessage("你成功扣除了 " + p.getName() + " :" + args[2] + "积分");
								((Player) p).sendMessage("管理员扣除了你 " + args[2] + " 积分");
								return true;
							} catch(NumberFormatException e) {
								//<数量>不是整数
								sender.sendMessage(args[1] + "好像不是一个整数诶？");
								return true;
							} catch(IOException e) {
								//数据文件丢失
								sender.sendMessage("数据文件丢失,请联系管理员重载插件");
								return true;
							}
						} else {
							//玩家不存在
							sender.sendMessage("玩家： " + args[1] + " 不存在");
							return true;
						}
					}
					if(sender instanceof Player) {
						//玩家输入命令
						if(sender.isOp()) {
							//sender是OP
							p = Bukkit.getOfflinePlayer(args[1]);
							key = "Data." + p.getUniqueId() + ".score";
							try {
								value = playerData.getLong(key) - Long.parseLong(args[2]);
								playerData.set(key, value);
								playerData.save(playerDataFile);
								sender.sendMessage("你成功奖励了 " + p.getName() + " :" + args[2] + "积分");
								((Player) p).sendMessage(((Player)sender).getName() + "奖励了你 " + args[2] + " 积分");
								return true;
							} catch(NumberFormatException e) {
								//<数量>不是整数
								sender.sendMessage(args[1] + "好像不是一个整数诶？");
								return true;
							} catch(IOException e) {
								//数据文件丢失
								sender.sendMessage("数据文件丢失,请联系管理员重载插件");
								return true;
							}
						} else {
							//sender不是OP
							sender.sendMessage("喵~管理员才能使用这条命令呢");
							return true;
						}
					}
				default:
					sender.sendMessage("命令格式不正确，请输入: /points help 获取帮助");
					return true;
				}
			} else {
				
			}
			sender.sendMessage("命令格式不正确，请输入: /points help 获取帮助");
			return true;
		}
	}
	
}
